#1. Como cargar mis datos
library(here)
DatosFolder<-here("01Datos")
Pingus<-read_csv(paste0(DatosFolder,'/DatosPinguinos.csv'))

#2. Cual es mi numero de muestras por sexo
Pingus %>%
  group_by(sexo)%>%
  tally()

#3. Cual es el promedio de peso por sexo
Pingus %>%
  group_by (sexo) %>%
  summarise(promedio=mean(largo_pico_mm))

#4. Un boxplot de pesos de hembras y machos separados por especie.
MiGrafico<-ggplot(Pingus,
                  aes(x=especie, y=largo_pico_mm, color=sexo, fill=sexo))+
  geom_boxplot()+
  theme_bw()
MiGrafico

#5. Elige el directorio donde quieres guardar tu gráfico.
ResultsFolder<-here::here("03Resultados")

#6. Exportar mi grafico
MiGrafico
ggsave("02_Grafico_LargoPico.jpg",
       path = ResultsFolder, #tambien la pueden escribir aqui
       width = 16, height = 8, 
       units = "in") #puede ser centimetros
